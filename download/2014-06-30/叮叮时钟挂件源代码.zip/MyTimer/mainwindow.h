#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QDateTime>
#include <QSystemTrayIcon>
#include <QMenu>
#include <QFile>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event); // 绘制象形时间，即周边三个圆环
    void timeUpdate(); // 更新时间
    void createTrayIcon(); // 创建托盘图标及右键菜单
    void AutoStart(); // 设置开机自启动

private:
    QTimer *timer;
    QDateTime current_DateTime;
    QLabel labelDate1, labelTime, labelDate2; // 分别显示 周、时间、日期，对应显示三行
    int hour;
    int minute;
    int second;
    int year;
    int month;
    int day;
    int week;
    QString is_auto_start;
    QSystemTrayIcon *trayIcon;
    QMenu *trayIconMenu;
    QAction *atstartAction;
    QAction *minimizeAction;
    QAction *restoreAction;
    QAction *quitAction;
    QFile *f;

};

#endif // MAINWINDOW_H
