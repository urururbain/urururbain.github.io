#include "mainwindow.h"
#include <QPaintEvent>
#include <QPainter>
#include <QPainterPath>
#include <QLabel>
#include <QTimer>
#include <QFont>
#include <QConicalGradient>
#include <QDateTime>
#include <QSystemTrayIcon>
#include <QAction>
#include <QApplication>
#include <QFile>
#include <QTextStream>
#include <QSettings>

#define REG_RUN "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    second = 0;
    minute = 0;
    hour = 0;

    f = new QFile("inf.ini");
    if(!f->open(QIODevice::ReadOnly | QIODevice::Text))
        ;
    QTextStream inf(f);
    is_auto_start = inf.read(1); // 读取第一个字符，判断初始是否开机自动启
    f->close();

    createTrayIcon(); // 创建托盘图标及右键菜单
    trayIcon->show();

    setWindowFlags(Qt::FramelessWindowHint|Qt::Tool);
    setAttribute(Qt::WA_TranslucentBackground);
    setWindowIcon(QIcon(":/ico/ICON"));
    setGeometry(1160, 10, 190, 190);

    timer = new QTimer(this); // 新建计时器
    connect(timer, &QTimer::timeout, this, &MainWindow::timeUpdate);

    QFont label_font;
    label_font.setFamily("Microsoft Yahei");
    //星期一
    label_font.setPointSize(22);
    labelDate1.setParent(this);
    labelDate1.setFont(label_font);
    labelDate1.setGeometry(0, 30, 190, 50);
    labelDate1.setAlignment(Qt::AlignCenter);
    //17:19:42
    label_font.setPointSize(26);
    labelTime.setParent(this);
    labelTime.setFont(label_font);
    labelTime.setGeometry(0, 70, 190, 50);
    labelTime.setAlignment(Qt::AlignCenter);
    //2014年06月30日
    label_font.setPointSize(12);
    labelDate2.setParent(this);
    labelDate2.setFont(label_font);
    labelDate2.setGeometry(0, 105, 190, 50);
    labelDate2.setAlignment(Qt::AlignCenter);
    //开始计时
    timer->start(1000);
}

MainWindow::~MainWindow()
{
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    //绘制路径，外围圆环
    QPainterPath path(QPointF(95, 14));
    if(second == 0)
        second = 60;
    path.arcTo(QRectF(0, 0, 190, 190), 90, -6*second);
    path.arcTo(QRectF(14, 14, 162, 162), 90-6*second, 6*second);
    if(second == 60)
        second = 0;
    path.moveTo(95, 17);
    path.arcTo(QRectF(15, 15, 160, 160), 90, -6*(minute+second/60.0));
    path.arcTo(QRectF(17, 17, 156, 156), 90-6*(minute+second/60.0), 6*(minute+second/60.0));
    path.moveTo(95, 20);
    path.arcTo(QRectF(18, 18, 154, 154), 90, -30*(hour%12 + minute/60.0 ));
    path.arcTo(QRectF(20, 20, 150, 150), 90-30*(hour%12 + minute/60.0 ), 30*(hour%12 + minute/60.0 ));

    //添加锥形渐变
    QConicalGradient conicalGradient(QPointF(95, 95), 90);
    conicalGradient.setColorAt(0.0, Qt::red);
    conicalGradient.setColorAt(1.0, Qt::white);
    //开始绘制圆环
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);//添加反走样
    painter.setPen(QColor(0, 0, 0, 0));//删除边框，即颜色置为全透明
    painter.setBrush(conicalGradient);
    painter.drawPath(path);
}

void MainWindow::timeUpdate()
{
    current_DateTime = QDateTime::currentDateTime();
    hour   = current_DateTime.time().hour();
    minute = current_DateTime.time().minute();
    second = current_DateTime.time().second();
    year = current_DateTime.date().year();
    month = current_DateTime.date().month();
    day = current_DateTime.date().day();
    week = current_DateTime.date().dayOfWeek();

    labelDate1.setText("<font color=white>"+current_DateTime.toString("dddd")+"</font>");
    labelTime.setText("<font color=white>"+current_DateTime.toString("hh:mm:ss")+"</font>");
    labelDate2.setText("<font color=white>"+current_DateTime.toString("yyyy年MM月dd日")+"</font>");

    update();
}

void MainWindow::createTrayIcon()
{ // 创建托盘图标及右键菜单
    trayIcon = new QSystemTrayIcon(this);
    trayIcon->setIcon(QIcon(":/ico/ICON"));
    trayIcon->setToolTip("叮叮时钟挂件");
    //设置右键菜单：开机自启动，最小化，还原，退出
    trayIconMenu = new QMenu(this);
    atstartAction = new QAction("开机自启动", this);
    atstartAction->setCheckable(true);
    if(is_auto_start == "1")
        atstartAction->setChecked(true);
    connect(atstartAction, &QAction::triggered, this, &MainWindow::AutoStart);
    minimizeAction = new QAction("最小化", this);
    connect(minimizeAction, &QAction::triggered, this, &MainWindow::hide);
    restoreAction = new QAction("还原", this);
    connect(restoreAction, &QAction::triggered, this, &MainWindow::showNormal);
    quitAction = new QAction("退出", this);
    connect(quitAction, &QAction::triggered, this, &QApplication::quit);
    //添加右键菜单
    trayIconMenu->addAction(atstartAction);
    trayIconMenu->addAction(minimizeAction);
    trayIconMenu->addAction(restoreAction);
    trayIconMenu->addSeparator();//分割线
    trayIconMenu->addAction(quitAction);

    trayIcon->setContextMenu(trayIconMenu);
    connect(trayIcon, &QSystemTrayIcon::activated, this, &MainWindow::showNormal);
}

void MainWindow::AutoStart()
{// 设置开机自启动
    if(atstartAction->isChecked())
        is_auto_start = "1";
    else
        is_auto_start = "0";

    QString application_name = QApplication::applicationName();
    QSettings *settings = new QSettings(REG_RUN, QSettings::NativeFormat);
    if(is_auto_start == "1")
    {
        QString application_path = QApplication::applicationFilePath();
        settings->setValue(application_name, application_path.replace("/", "\\"));
    }
    else
    {
        settings->remove(application_name);
    }

    if(!f->open(QIODevice::WriteOnly | QIODevice::Text))
        ;
    QTextStream inf(f);
    inf << is_auto_start << endl;
    f->close();
}
